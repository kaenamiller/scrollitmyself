document.addEventListener('DOMContentLoaded', () => {
    const slider = document.getElementById('sensitivity');
    const valueDisplay = document.getElementById('sensitivity-value');
    const newDomainInput = document.getElementById('new-domain');
    const addDomainBtn = document.getElementById('add-domain');
    const blacklistUl = document.getElementById('blacklist');

    // 1. Load saved settings
    chrome.storage.sync.get(['sensitivity', 'blacklist'], (result) => {
        // Default to 30 if not set (matches the multiplier 0.03)
        const currentVal = result.sensitivity || 30;
        slider.value = currentVal;
        valueDisplay.textContent = currentVal;

        // Load blacklist
        const blacklist = result.blacklist || [];
        renderBlacklist(blacklist);
    });

    // 2. Save settings when slider changes
    slider.addEventListener('input', () => {
        const val = parseInt(slider.value, 10);
        valueDisplay.textContent = val;

        chrome.storage.sync.set({ sensitivity: val });
    });

    // 3. Blacklist Logic
    function renderBlacklist(list) {
        blacklistUl.innerHTML = '';
        list.forEach(domain => {
            const li = document.createElement('li');
            li.style.display = 'flex';
            li.style.justifyContent = 'space-between';
            li.style.alignItems = 'center';
            li.style.padding = '5px';
            li.style.borderBottom = '1px solid #eee';

            const span = document.createElement('span');
            span.textContent = domain;
            span.style.overflow = 'hidden';
            span.style.textOverflow = 'ellipsis';
            span.style.whiteSpace = 'nowrap';
            span.style.maxWidth = '130px';
            span.title = domain; // Tooltip for full name

            const btnContainer = document.createElement('div');
            btnContainer.style.display = 'flex';
            btnContainer.style.gap = '5px';

            const editBtn = document.createElement('button');
            editBtn.textContent = '\u270E'; // Pencil icon
            editBtn.style.cursor = 'pointer';
            editBtn.style.padding = '2px 5px';
            editBtn.style.fontSize = '10px';
            editBtn.title = 'Edit';
            editBtn.onclick = () => {
                removeDomain(domain, () => {
                    newDomainInput.value = domain;
                    newDomainInput.focus();
                });
            };

            const delBtn = document.createElement('button');
            delBtn.textContent = '\u00D7'; // Multiplication sign (X)
            delBtn.style.cursor = 'pointer';
            delBtn.style.padding = '2px 5px';
            delBtn.style.color = 'red';
            delBtn.style.fontSize = '12px';
            delBtn.title = 'Remove';
            delBtn.onclick = () => removeDomain(domain);

            btnContainer.appendChild(editBtn);
            btnContainer.appendChild(delBtn);
            li.appendChild(span);
            li.appendChild(btnContainer);
            blacklistUl.appendChild(li);
        });
    }

    function addDomain() {
        const domain = newDomainInput.value.trim();
        if (!domain) return;

        chrome.storage.sync.get(['blacklist'], (result) => {
            const list = result.blacklist || [];
            if (!list.includes(domain)) {
                list.push(domain);
                chrome.storage.sync.set({ blacklist: list }, () => {
                    renderBlacklist(list);
                    newDomainInput.value = '';
                });
            } else {
                newDomainInput.value = ''; // Clear if duplicate
            }
        });
    }

    function removeDomain(domain, callback) {
        chrome.storage.sync.get(['blacklist'], (result) => {
            let list = result.blacklist || [];
            list = list.filter(d => d !== domain);
            chrome.storage.sync.set({ blacklist: list }, () => {
                renderBlacklist(list);
                if (callback) callback();
            });
        });
    }

    addDomainBtn.addEventListener('click', addDomain);
    newDomainInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') addDomain();
    });
});
