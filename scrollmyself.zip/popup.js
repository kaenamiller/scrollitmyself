document.addEventListener('DOMContentLoaded', () => {
    const slider = document.getElementById('sensitivity');
    const valueDisplay = document.getElementById('sensitivity-value');

    // 1. Load saved settings
    chrome.storage.sync.get(['sensitivity'], (result) => {
        // Default to 30 if not set (matches the multiplier 0.03)
        const currentVal = result.sensitivity || 30;
        slider.value = currentVal;
        valueDisplay.textContent = currentVal;
    });

    // 2. Save settings when slider changes
    slider.addEventListener('input', () => {
        const val = parseInt(slider.value, 10);
        valueDisplay.textContent = val;

        chrome.storage.sync.set({ sensitivity: val }, () => {
            // Optional: debug log
            // console.log('Sensitivity saved:', val);
        });
    });
});
