(function () {
    let isScrolling = false;
    let originX = 0;
    let originY = 0;
    let scrollSpeedX = 0;
    let scrollSpeedY = 0;
    let animationFrameId = null;
    let originIcon = null;

    // The element currently being scrolled (null means window)
    let activeScrollTarget = null;

    // Configuration
    const SCROLL_DEADZONE = 20;
    const MAX_SPEED = 300;

    let scrollMultiplier = 0.15;

    // Initialize Settings
    if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.sync.get(['sensitivity'], (result) => {
            if (result.sensitivity) {
                scrollMultiplier = result.sensitivity / 200;
            }
        });

        chrome.storage.onChanged.addListener((changes, namespace) => {
            if (changes.sensitivity) {
                scrollMultiplier = changes.sensitivity.newValue / 200;
            }
        });
    }

    function createIcon() {
        const icon = document.createElement('div');
        icon.id = 'autoscroll-origin-icon';
        return icon;
    }

    // Helper: Find the nearest scrollable ancestor
    function getScrollParent(node) {
        if (!node) return null;

        // Traverse up the DOM
        while (node && node !== document.body && node !== document.documentElement) {
            // 1. Check if it has scrollable overflow style
            const style = window.getComputedStyle(node);
            const overflowY = style.overflowY;
            const isScrollableStyle = overflowY === 'auto' || overflowY === 'scroll';

            // 2. Check if it actually has content larger than its height
            const canScroll = node.scrollHeight > node.clientHeight;

            if (isScrollableStyle && canScroll) {
                return node;
            }
            node = node.parentElement;
        }
        // If no specific container found, return null (implies window/body)
        return null;
    }

    // The main animation loop
    function scrollLoop() {
        if (!isScrolling) return;

        if (scrollSpeedX !== 0 || scrollSpeedY !== 0) {
            if (activeScrollTarget) {
                // Scroll the specific container
                activeScrollTarget.scrollBy(scrollSpeedX, scrollSpeedY);
            } else {
                // Scroll the main window
                window.scrollBy(scrollSpeedX, scrollSpeedY);
            }
        }

        animationFrameId = requestAnimationFrame(scrollLoop);
    }

    function startAutoscroll(e) {
        isScrolling = true;
        originX = e.clientX;
        originY = e.clientY;

        // DETECT TARGET: Find which element should scroll
        activeScrollTarget = getScrollParent(e.target);

        document.body.classList.add('autoscrolling');

        originIcon = createIcon();
        originIcon.style.left = `${originX}px`;
        originIcon.style.top = `${originY}px`;
        document.body.appendChild(originIcon);

        scrollLoop();
    }

    function stopAutoscroll() {
        isScrolling = false;
        activeScrollTarget = null; // Clear target
        scrollSpeedX = 0;
        scrollSpeedY = 0;

        if (animationFrameId) {
            cancelAnimationFrame(animationFrameId);
        }

        if (originIcon) {
            originIcon.remove();
            originIcon = null;
        }
        document.body.classList.remove('autoscrolling');
    }

    function isLink(target) {
        return target.tagName === 'A' || target.closest('a') !== null;
    }

    // 1. Handle the Middle Click Trigger
    document.addEventListener('mousedown', (e) => {
        if (e.button !== 1) {
            if (isScrolling) {
                stopAutoscroll();
                e.preventDefault();
                e.stopPropagation();
            }
            return;
        }

        if (isScrolling) {
            stopAutoscroll();
            e.preventDefault();
            e.stopPropagation();
            return;
        }

        if (isLink(e.target)) {
            return;
        }

        e.preventDefault();
        e.stopPropagation();
        startAutoscroll(e);
    }, { capture: true });

    // 2. Calculate Speed
    document.addEventListener('mousemove', (e) => {
        if (!isScrolling) return;

        const currentX = e.clientX;
        const currentY = e.clientY;

        const deltaX = currentX - originX;
        const deltaY = currentY - originY;

        if (Math.abs(deltaX) < SCROLL_DEADZONE) {
            scrollSpeedX = 0;
        } else {
            const rawSpeed = (deltaX - (Math.sign(deltaX) * SCROLL_DEADZONE)) * scrollMultiplier;
            scrollSpeedX = Math.max(Math.min(rawSpeed, MAX_SPEED), -MAX_SPEED);
        }

        if (Math.abs(deltaY) < SCROLL_DEADZONE) {
            scrollSpeedY = 0;
        } else {
            const rawSpeed = (deltaY - (Math.sign(deltaY) * SCROLL_DEADZONE)) * scrollMultiplier;
            scrollSpeedY = Math.max(Math.min(rawSpeed, MAX_SPEED), -MAX_SPEED);
        }
    });

    // 3. Prevent default Linux middle-click paste
    document.addEventListener('auxclick', (e) => {
        if (isScrolling && e.button === 1) {
            e.preventDefault();
            e.stopPropagation();
        }
    }, { capture: true });

    document.addEventListener('mouseup', (e) => {
        if (e.button === 1 && isScrolling) {
            e.preventDefault();
            e.stopPropagation();
        }
    }, { capture: true });

})();
